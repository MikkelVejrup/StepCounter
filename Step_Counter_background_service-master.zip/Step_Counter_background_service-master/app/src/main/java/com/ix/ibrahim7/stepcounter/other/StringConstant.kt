package com.ix.ibrahim7.stepcounter.other

const val TAG = "eee"
const val SHARE = "share"
const val STEPNUMBER = "step_number"
